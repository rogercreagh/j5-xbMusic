<?php 
 /*******
 * @package xbMusic
 * @filesource admin/src/Controller/DashboardController.php
 * @version 0.0.51.2 13th April 2025
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2024
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html 
 ******/

namespace Crosborne\Component\Xbmusic\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\AdminController;

class DashboardController extends AdminController
{
    public function getModel($name = 'Dashboard', $prefix = 'Administrator', $config = array('ignore_request' => true))
    {
        return parent::getModel($name, $prefix, $config);
    }

    //these redirect functions called from all list views 'other views' menu
    public function toDashboard() {
        $this->setRedirect('index.php?option=com_xbmusic&view=dashboard');
    }
    public function toAlbums() {
        $this->setRedirect('index.php?option=com_xbmusic&view=albums');
    }
    public function toArtists() {
        $this->setRedirect('index.php?option=com_xbmusic&view=artists');
    }
    public function toPlaylists() {
        $this->setRedirect('index.php?option=com_xbmusic&view=playlists');
    }
    public function toPlaylisttracks() {
        $jip =  $this->input;
        if ($jip->exists('cid')) {
            $id =  $jip->get('cid')[0];
        } else {
            $id = $this->input->getArray()['id'];
        }
        if ($id > 0) $this->setRedirect('index.php?option=com_xbmusic&view=playlisttracks&id='.$id);
    }
    public function toSchedule() {
        $this->setRedirect('index.php?option=com_xbmusic&view=schedule');
    }
    public function toSongs() {
        $this->setRedirect('index.php?option=com_xbmusic&view=songs');
    }
    public function toTracks() {
        $this->setRedirect('index.php?option=com_xbmusic&view=tracks');
    }
    public function toCats() {
        $this->setRedirect('index.php?option=com_xbmusic&view=catlist');
    }
    public function toTags() {
        $this->setRedirect('index.php?option=com_xbmusic&view=taglist');
    }
    public function toAzuracast() {
        $this->setRedirect('index.php?option=com_xbmusic&view=azuracast');
    }
    public function toDataman() {
        $this->setRedirect('index.php?option=com_xbmusic&view=dataman');
    }
}

