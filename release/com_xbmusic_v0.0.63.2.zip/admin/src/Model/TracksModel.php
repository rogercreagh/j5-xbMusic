<?php
/*******
 * @package xbMusic
 * @filesource admin/src/Model/TracksModel.php
 * @version 0.0.63.0 21st April 2026
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2024
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html 
 ******/

namespace Crosborne\Component\Xbmusic\Administrator\Model;

defined('_JEXEC') or die;


use Joomla\CMS\Factory;
use Joomla\CMS\Helper\TagsHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Utilities\ArrayHelper;
//use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Table\Table;
//use Crosborne\Component\Xbmusic\Administrator\Helper\XbmusicHelper;

class TracksModel extends ListModel {
    
    public function __construct($config = array())
    {
        if (empty($config['filter_fields']))
        {
            $config['filter_fields'] = array(
                'id', 'a.id',
                'title', 'a.title',
                'alias', 'a.alias',
                'rel_date', 'a.rel_date',
                'sortartist', 'a.sortartist',
                'albumtitle', 'album.title',
                'checked_out', 'a.checked_out',
                'checked_out_time', 'a.checked_out_time',
                'catid', 'a.catid', 'category_title',
                'status', 'a.status',
                'created', 'a.created',
                'modified', 'a.modified',
                'created_by', 'a.created_by',
                'created_by_alias', 'a.created_by_alias',
                'ordering', 'a.ordering',
                'status', 'category_id','tagfilt'
            );
            
        }
        
        parent::__construct($config);
    }
    
    protected function populateState($ordering = 'a.id', $direction = 'desc')
    {
        $app = Factory::getApplication();
        
        // Adjust the context to support modal layouts.
        if ($layout = $app->input->get('layout'))
        {
            $this->context .= '.' . $layout;
        }
        
        $filt = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search','');
        $this->setState('filter.search', $filt);
        
        $filt = $this->getUserStateFromRequest($this->context . '.filter.status', 'filter_status', '');
        $this->setState('filter.published', $filt);
                
        $filt = $this->getUserStateFromRequest($this->context . '.filter.tagfilt', 'filter_filter_tagfilt', '');
        $this->setState('filter.tagfilt', $filt);
        
        $filt = $this->getUserStateFromRequest($this->context . '.filter.taglogic', 'filter_filter_taglogic', '');
        $this->setState('filter.taglogic', $filt);
        
        $categoryId = $this->getUserStateFromRequest($this->context . '.filter.category_id', 'filter_category_id','');
        $formSubmited = $app->input->post->get('form_submited');
        if ($formSubmited)
        {
            $categoryId = $app->input->post->get('category_id');
            $this->setState('filter.category_id', $categoryId);
            
        }
        
        // List state information.
        parent::populateState($ordering, $direction);
        
    }
    
    protected function getStoreId($id = '')
    {
        // Compile the store id.
        $id .= ':' . $this->getState('filter.search');
        $id .= ':' . serialize($this->getState('filter.access'));
        $id .= ':' . $this->getState('filter.status');
        $id .= ':' . serialize($this->getState('filter.category_id'));
        
        return parent::getStoreId($id);
    }
    
    protected function getListQuery() {
        
        // Create a new query object.
        $db    = $this->getDatabase();
        $query = $db->getQuery(true);
        $app = Factory::getApplication();
        $user  = $app->getIdentity();
        
        // Select the required fields from the table.
        $query->select(
            $this->getState(
                'list.select',
                'DISTINCT a.id, a.title, a.alias, a.description, a.filename, a.filepathname, a.imgurl,'
                    .'a.rec_date, a.rel_date, a.sortartist, a.ext_links, a.checked_out, a.checked_out_time, a.catid, '
                    .'a.status, a.access, a.created, a.created_by, a.created_by_alias, a.modified, a.ordering, '
                    .'a.note, album.title AS albumtitle, a.album_id AS albumid'
                )
            );
        $query->from('#__xbmusic_tracks AS a');
                
        // join album, 
        $query->join('LEFT', '#__xbmusic_albums AS album ON album.id = a.album_id');
        // get songs, artists, playlists in getItems()
        
        // Join over the users for the checked out user.
        $query->select('uc.name AS editor')
        ->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');
        
        // Join over the categories.
        $query->select('c.title AS category_title, c.created_user_id AS category_uid'.
            ',c.path AS category_path')
            ->join('LEFT', '#__categories AS c ON c.id = a.catid');
            
        // Join over the parent categories.
        $query->select('parent.title AS parent_category_title, parent.id AS parent_category_id,'.
						'parent.created_user_id AS parent_category_uid, parent.level AS parent_category_level')
						->join('LEFT', '#__categories AS parent ON parent.id = c.parent_id');
						
		// Filter by access level.
		$access = $this->getState('filter.access');
		
		if (is_numeric($access)) {
		    $query->where('a.access = ' . (int) $access);
		} elseif (is_array($access)) {
		    $access = ArrayHelper::toInteger($access);
		    $access = implode(',', $access);
		    $query->where('a.access IN (' . $access . ')');
		}
		
		// Filter by access level on categories.
		if (!$user->authorise('core.admin')) {
		    $groups = implode(',', $user->getAuthorisedViewLevels());
		    $query->where('a.access IN (' . $groups . ')');
		    $query->where('c.access IN (' . $groups . ')');
		}
		
		// Filter by published state
		$status = $this->getState('filter.status');
		
		if (is_numeric($status)) {
		    $query->where('a.status = ' . (int) $status);
		} elseif ($status === '') {
		    $query->where('(a.status = 0 OR a.status = 1)');
		}
		
		// Filter by categories
		$categoryId = $this->getState('filter.category_id', array());
		
		if (is_array($categoryId) && (!empty($categoryId))) $categoryId = $categoryId[0];
		if (is_numeric($categoryId)) $query->where($db->quoteName('a.catid') . ' = ' . (int) $categoryId);
		
		// Filter by search in title.
		$search = $this->getState('filter.search');
		
		if (!empty($search))
		{
		    if (stripos($search, 'id:') === 0)
		    {
		        $query->where('a.id = ' . (int) substr($search, 3));
		    }
		    elseif (stripos($search, 'desc:') === 0)
		    {
		        $search = $db->quote('%' . $db->escape(substr($search, 8), true) . '%');
		        $query->where('(a.desc LIKE ' . $search . ')');
		    }
		    elseif (stripos($search, 'note:') === 0)
		    {
		        $search = $db->quote('%' . $db->escape(substr($search, 8), true) . '%');
		        $query->where('(a.note LIKE ' . $search . ')');
		    }
		    else
		    {
		        $search = $db->quote('%' . str_replace(' ', '%', $db->escape(trim($search), true) . '%'));
		        $query->where('(a.title LIKE ' . $search . ' OR a.alias LIKE ' . $search . ')');
		    }
		} // endif $search 
		
		//filter by tags
		$tagfilt = '';
		//is tagid in query string. If so use it and ignore tag filters. Negative tagid to exclude tag
		$tagId = (int) $app->getUserStateFromRequest('tagid', 'tagid','');
		$app->setUserState('tagid', '');
		if (!empty($tagId)) {
		    $tagfilt = array(abs($tagId));
		    $taglogic = $tagId>0 ? 0 : 2;
		} else {
		    $tagfilt = $this->getState('filter.tagfilt');
		    $taglogic = $this->getState('filter.taglogic',0);  //0=ANY 1=ALL 2= None
		}
		if (!is_array($tagfilt)) {
		    $tagfilt = array($tagfilt);
    	}
    	if ($tagfilt[0] > 0) {
    	    $tagfilt = ArrayHelper::toInteger($tagfilt);
    	    $subquery = '(SELECT tmap.tag_id AS tlist FROM #__contentitem_tag_map AS tmap
                    WHERE tmap.type_alias = '.$db->quote('com_xbmusic.track').'
                    AND tmap.content_item_id = a.id)';
    	    switch ($taglogic) {
    	        case 1: //all tags must be matched
    	            for ($i = 0; $i < count($tagfilt); $i++) {
    	                $query->where($tagfilt[$i].' IN '.$subquery);
    	            }
    	            break;
    	        case 2: //none of the tags must be matched
    	            for ($i = 0; $i < count($tagfilt); $i++) {
    	                $query->where($tagfilt[$i].' NOT IN '.$subquery);
    	            }
    	            break;
    	        case 0: //any match will do
    	            if (count($tagfilt) == 1) {
    	                $query->where($tagfilt[0].' IN '.$subquery);
    	            } else {
    	                $tagIds = implode(',', $tagfilt);
    	                if ($tagIds) {
    	                    $subQueryAny = '(SELECT DISTINCT content_item_id AS cid FROM #__contentitem_tag_map
                                    WHERE tag_id IN ('.$tagIds.') AND type_alias = '.$db->quote('com_xbmusic.track').')';
    	                    $query->innerJoin('(' . (string) $subQueryAny . ') AS tm ON tm.cid = a.id');
    	                }
    	            } //end else
    	            break;
            } //endswitch
    	}
        // Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'a.id');
		$orderDirn = $this->state->get('list.direction', 'DESC');
		
		if ($orderCol=='a.ordering') {
		    $orderCol='category_title '.$orderDirn.', a.ordering';
		}
		
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		
		return $query;
    } //end getlistquery
    
    public function getItems() {
        $items  = parent::getItems();
        if ($items) {
            $tagsHelper = new TagsHelper;
            foreach ($items as $item) {
                if($item->ext_links) $item->ext_links = json_decode($item->ext_links);
                $item->ext_links_list ='';
                $item->ext_links_cnt = 0;
                if(is_object($item->ext_links)) {
                    $item->ext_links_cnt = count((array)$item->ext_links);
                    if ($item->ext_links_cnt > 0) {
                        $item->ext_links_list ='<ul>';
                        foreach($item->ext_links as $lnk) {
                            $item->ext_links_list .= '<li><a href="'.$lnk->link_url.'" target="_blank">'.$lnk->link_text.'</a></li>';
                        }
                        $item->ext_links_list = $item->ext_links_list.'</ul>';                        
                    }
                } //end if is_object
                $item->songs = $this->getSongs($item->id);
                $item->artists = $this->getArtists($item->id);
                
                $item->playlists = array();
                
                $item->tags = $tagsHelper->getItemTags('com_xbmusic.track' , $item->id);               
            } //end foreach
        } //endif items
        return $items;
        
    } // end getItems

    public function getSongs($id) {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);
        $query->select('a.id as id, a.title, st.note, st.listorder');
        $query->from('#__xbmusic_songs AS a');
        $query->join('LEFT','#__xbmusic_tracksong AS st ON st.song_id = a.id');
        $query->where('st.track_id = '.$id);
        $query->order('st.listorder ASC');
        $db->setQuery($query);
        return $db->loadAssocList();
    }
    
    public function getArtists($id) {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);
        $query->select('a.id AS id, a.name, b.role, b.note, b.listorder');
        $query->from('#__xbmusic_artists AS a');
        $query->join('LEFT','#__xbmusic_trackartist AS b ON b.artist_id = a.id');
        $query->where('b.track_id = '.$id);
        $query->order('b.listorder ASC');
        $db->setQuery($query);
        return $db->loadAssocList();
    }
    
}

